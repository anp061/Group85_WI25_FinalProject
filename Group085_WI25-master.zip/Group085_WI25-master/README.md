# Group85_WI25_FinalProject

My contributions to the group project: Brainstormed research questions, worked on EDA visuals, started presentation slides (worked on research question, hypothesis, and visuals slides), recorded visual portion of the team video, and proofread and made minor adjustments to overall project.
